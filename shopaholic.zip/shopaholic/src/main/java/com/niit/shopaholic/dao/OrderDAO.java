package com.niit.shopaholic.dao;

import com.niit.shopaholic.model.UserOrder;

public interface OrderDAO {
	void addOrder(UserOrder userOrder);
    double getOrderGrandTotal(int cartId);
}

